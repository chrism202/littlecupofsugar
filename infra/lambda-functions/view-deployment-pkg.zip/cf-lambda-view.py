import boto3
import secrets
import datetime
import json

db = boto3.client('dynamodb')

def handler(event, context):
  
  # item_id = json.dumps(event)
  # print(item_id) # string
  # print(type(event)) # dict
  
  specific_item = event["postid"]

  # possibly...
  # database = db.Table('lcos-dev-cfstack-createdb-myDynamoDBTable-12WJFULYOYUJK')
  # item = database.get_item(Key)


  db_item = db.get_item(
    TableName='lcos-dev-cfstack-createdb-myDynamoDBTable-12WJFULYOYUJK',
    Key={'lcos_masterlist_pk' : specific_item}
    )



  # def get_movie(title, year, dynamodb=None):
  #   if not dynamodb:
  #       dynamodb = boto3.resource('dynamodb', endpoint_url="http://localhost:8000")

  #   table = dynamodb.Table('Movies')

  #   try:
  #       response = table.get_item(Key={'year': year, 'title': title})
  #   except ClientError as e:
  #       print(e.response['Error']['Message'])
  #   else:
  #       return response['Item']


# if __name__ == '__main__':
#     movie = get_movie("The Big New Movie", 2015,)
#     if movie:
#         print("Get movie succeeded:")
#         pprint(movie, sort_dicts=False)

  response = {
      'statusCode': 200,
      'body': 'successfully retrieved item!',
      'items' : {
        'URL' : db_item,
      },  
      'headers': {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
  }
  
  return response
